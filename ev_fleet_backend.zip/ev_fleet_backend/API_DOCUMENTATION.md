# EV Fleet Management API Documentation

## Database Setup
1. Install PostgreSQL
2. Create database: `ABC_IT_DB`
3. Update credentials in `app/database.py` or set environment variables:
   - DB_USER=postgres
   - DB_PASSWORD=your_password
   - DB_HOST=localhost
   - DB_PORT=5432
   - DB_NAME=ABC_IT_DB

## Run Application
```bash
python init_db.py  # Initialize database
python -m uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

## API Endpoints

### 🔐 RIDER AUTHENTICATION
- **POST** `/api/rider/register` - Register new rider (all fields optional)
- **POST** `/api/rider/login` - Rider login (requires approval)

### 👤 RIDER DASHBOARD & PROFILE  
- **GET** `/api/rider/dashboard` - Get dashboard data
- **GET** `/api/rider/profile` - Get rider profile

### 💰 RIDER WALLET
- **GET** `/api/rider/wallet` - Get wallet information
- **POST** `/api/rider/wallet/add-hours` - Add hours to wallet

### 📄 RIDER DOCUMENTS
- **GET** `/api/rider/documents` - Get documents with approval status
- **POST** `/api/rider/documents/upload` - Upload/update documents

### 🚗 RIDER VEHICLE CONTROL
- **GET** `/api/rider/vehicle` - Get vehicle information
- **POST** `/api/rider/vehicle/on` - Turn vehicle ON
- **POST** `/api/rider/vehicle/off` - Turn vehicle OFF
- **GET** `/api/rider/vehicle/status` - Get vehicle status

### 🔧 ADMIN AUTHENTICATION
- **POST** `/api/admin/login` - Admin login (username: admin, password: admin123)

### 📊 ADMIN MANAGEMENT
- **GET** `/api/admin/dashboard` - Admin dashboard statistics
- **GET** `/api/admin/riders/pending` - Get pending riders for approval
- **GET** `/api/admin/riders/approved` - Get approved riders
- **POST** `/api/admin/approve-document` - Approve/reject specific document
- **POST** `/api/admin/approve-rider/{rider_id}` - Approve entire rider
- **POST** `/api/admin/reject-rider/{rider_id}` - Reject rider

## Key Features
✅ No required fields for registration
✅ Admin approval workflow for each document
✅ Rider can only login after admin approval
✅ PostgreSQL database (ABC_IT_DB)
✅ JWT authentication
✅ File upload support
✅ CORS enabled
✅ Comprehensive error handling

## Default Admin Credentials
- Username: `admin`
- Password: `admin123`

## API Documentation
- Swagger UI: http://localhost:8000/docs
- ReDoc: http://localhost:8000/redoc