# EV Fleet Management - Rider System Backend

FastAPI backend for EV Fleet Management Rider Module with complete authentication, document management, wallet system, and vehicle control.

## Features

### 🔐 Rider Authentication
- **Signup**: Register with documents upload (PDF, JPG, PNG)
- **Login**: JWT-based authentication
- **Security**: bcrypt password hashing

### 📊 Rider Dashboard
- Real-time ride status
- Wallet hours display
- Vehicle information
- Battery percentage
- Location tracking

### 💰 Wallet Management
- View available hours
- Track used hours
- Total hours management

### 📄 Document Management
- Upload/update documents
- Support for: Driving License, Aadhaar, PAN, Address Proof, Photo
- File validation and storage

### 🚗 Vehicle Control
- View vehicle information
- Turn vehicle ON/OFF
- Battery and location status

## Quick Start

### 1. Install PostgreSQL
Install PostgreSQL on your system:
- **Windows**: Download from https://www.postgresql.org/download/windows/
- **macOS**: `brew install postgresql`
- **Linux**: `sudo apt-get install postgresql postgresql-contrib`

### 2. Setup Database
```bash
# Create database
psql -U postgres
CREATE DATABASE ev_fleet_db;
\q
```

### 3. Configure Environment
```bash
# Copy environment file
cp .env.example .env

# Update .env with your PostgreSQL credentials:
# DATABASE_URL=postgresql://username:password@localhost:5432/ev_fleet_db
```

### 4. Install Dependencies
```bash
cd ev_fleet_backend
pip install -r requirements.txt
```

### 5. Run Server
```bash
uvicorn app.main:app --reload
```

### 6. Access API
- **API**: http://localhost:8000
- **Swagger Docs**: http://localhost:8000/docs
- **ReDoc**: http://localhost:8000/redoc

## API Endpoints

### Authentication
- `POST /api/rider/register` - Rider signup with documents
- `POST /api/rider/login` - Rider login

### Dashboard & Data
- `GET /api/rider/dashboard` - Dashboard data
- `GET /api/rider/wallet` - Wallet information
- `GET /api/rider/vehicle` - Vehicle information

### Document Management
- `GET /api/rider/documents` - Get documents
- `POST /api/rider/documents/upload` - Upload/update documents

### Vehicle Control
- `POST /api/rider/vehicle/on` - Turn vehicle ON
- `POST /api/rider/vehicle/off` - Turn vehicle OFF

## Database Schema

### Tables
- **riders**: User accounts
- **rider_documents**: Document storage
- **vehicles**: Vehicle information
- **wallets**: Wallet management

## File Structure
```
ev_fleet_backend/
├── app/
│   ├── main.py              # FastAPI app
│   ├── database.py          # Database config
│   ├── models.py            # SQLAlchemy models
│   ├── schemas.py           # Pydantic schemas
│   ├── auth.py              # JWT authentication
│   └── routers/
│       ├── rider_auth.py    # Authentication APIs
│       ├── dashboard.py     # Dashboard APIs
│       ├── wallet.py        # Wallet APIs
│       ├── documents.py     # Document APIs
│       └── vehicle.py       # Vehicle APIs
├── uploads/                 # File storage
└── requirements.txt         # Dependencies
```

## Security Features
- JWT token authentication
- bcrypt password hashing
- File upload validation
- CORS middleware
- Request/response validation

## Ready for Production
- Modular architecture
- Proper error handling
- API documentation
- Database relationships
- File management system