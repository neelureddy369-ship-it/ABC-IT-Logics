from app.database import SessionLocal
from app.models import Vehicle, RideHistory, PaymentHistory, Rider, Wallet
from datetime import datetime, timedelta

db = SessionLocal()

try:
    # Add sample vehicles if they don't exist
    vehicles_data = [
        {"vehicle_number": "EV-1001", "sim_number": "SIM001", "imei_number": "IMEI001", "iot_device": "IOT001", 
         "battery_percentage": 78, "location": "MG Road, Bangalore", "status": "Running", "ignition_status": False},
        {"vehicle_number": "EV-1002", "sim_number": "SIM002", "imei_number": "IMEI002", "iot_device": "IOT002", 
         "battery_percentage": 92, "location": "Koramangala, Bangalore", "status": "Idle", "ignition_status": True},
        {"vehicle_number": "EV-1003", "sim_number": "SIM003", "imei_number": "IMEI003", "iot_device": "IOT003", 
         "battery_percentage": 65, "location": "Whitefield, Bangalore", "status": "Running", "ignition_status": True},
        {"vehicle_number": "EV-1004", "sim_number": "SIM004", "imei_number": "IMEI004", "iot_device": "IOT004", 
         "battery_percentage": 12, "location": "Whitefield, Bangalore", "status": "Offline", "ignition_status": False},
        {"vehicle_number": "EV-1005", "sim_number": "SIM005", "imei_number": "IMEI005", "iot_device": "IOT005", 
         "battery_percentage": 100, "location": "HSR Layout, Bangalore", "status": "Idle", "ignition_status": True},
        {"vehicle_number": "EV-1006", "sim_number": "SIM006", "imei_number": "IMEI006", "iot_device": "IOT006", 
         "battery_percentage": 88, "location": "Electronic City, Bangalore", "status": "Running", "ignition_status": True},
    ]
    
    for vehicle_data in vehicles_data:
        existing = db.query(Vehicle).filter(Vehicle.vehicle_number == vehicle_data["vehicle_number"]).first()
        if not existing:
            vehicle = Vehicle(**vehicle_data)
            db.add(vehicle)
    
    db.commit()
    print("Sample vehicles added successfully!")
    
    # Add sample ride and payment history for existing riders
    riders = db.query(Rider).all()
    for rider in riders:
        # Add sample ride history
        existing_ride = db.query(RideHistory).filter(RideHistory.rider_id == rider.id).first()
        if not existing_ride:
            vehicle = db.query(Vehicle).first()
            if vehicle:
                ride = RideHistory(
                    rider_id=rider.id,
                    vehicle_id=vehicle.id,
                    start_time=datetime(2026, 3, 5, 10, 30, 0),
                    end_time=datetime(2026, 3, 10, 15, 47, 3),
                    duration_hours=125.28,
                    status="completed"
                )
                db.add(ride)
        
        # Add sample payment history
        existing_payment = db.query(PaymentHistory).filter(PaymentHistory.rider_id == rider.id).first()
        if not existing_payment:
            payment = PaymentHistory(
                rider_id=rider.id,
                amount=5000.0,
                hours_credited=100,
                payment_date=datetime(2026, 2, 15)
            )
            db.add(payment)
    
    db.commit()
    print("Sample data added successfully!")
    
except Exception as e:
    print(f"Error adding sample data: {e}")
    db.rollback()
    
finally:
    db.close()