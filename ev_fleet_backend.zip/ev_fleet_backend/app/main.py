from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from .database import engine, Base
from .routers import rider_auth, dashboard, wallet, documents, vehicle, admin

# Create database tables
Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="EV Fleet Management - Rider System",
    description="FastAPI backend for EV Fleet Management Rider Module",
    version="1.0.0"
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(rider_auth.router)
app.include_router(dashboard.router)
app.include_router(wallet.router)
app.include_router(documents.router)
app.include_router(vehicle.router)
app.include_router(admin.router)

@app.get("/")
async def root():
    return {"message": "EV Fleet Management - Rider System API", "version": "1.0.0"}

@app.get("/health")
async def health_check():
    return {"status": "healthy"}