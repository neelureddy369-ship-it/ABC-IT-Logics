from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, Float, Boolean
from sqlalchemy.orm import relationship
from datetime import datetime
from .database import Base

class Rider(Base):
    __tablename__ = "riders"
    
    id = Column(Integer, primary_key=True, index=True)
    full_name = Column(String)
    phone_number = Column(String, unique=True)
    aadhaar_number = Column(String)
    password_hash = Column(String)
    is_approved = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    assigned_vehicle_id = Column(Integer, ForeignKey("vehicles.id"), nullable=True)
    
    documents = relationship("RiderDocument", back_populates="rider")
    wallet = relationship("Wallet", back_populates="rider")
    topup_requests = relationship("TopUpRequest", back_populates="rider")
    ride_history = relationship("RideHistory", back_populates="rider")
    payment_history = relationship("PaymentHistory", back_populates="rider")
    assigned_vehicle = relationship("Vehicle", foreign_keys=[assigned_vehicle_id])

class RiderDocument(Base):
    __tablename__ = "rider_documents"
    
    id = Column(Integer, primary_key=True, index=True)
    rider_id = Column(Integer, ForeignKey("riders.id"))
    driving_license = Column(String)
    driving_license_approved = Column(Boolean, default=False)
    aadhaar_card = Column(String)
    aadhaar_card_approved = Column(Boolean, default=False)
    pan_card = Column(String)
    pan_card_approved = Column(Boolean, default=False)
    address_proof = Column(String)
    address_proof_approved = Column(Boolean, default=False)
    photo_selfie = Column(String)
    photo_selfie_approved = Column(Boolean, default=False)
    
    rider = relationship("Rider", back_populates="documents")

class TopUpRequest(Base):
    __tablename__ = "topup_requests"
    
    id = Column(Integer, primary_key=True, index=True)
    rider_id = Column(Integer, ForeignKey("riders.id"))
    hours = Column(Integer)
    status = Column(String, default="pending")  # pending, approved, rejected
    created_at = Column(DateTime, default=datetime.utcnow)
    
    rider = relationship("Rider", back_populates="topup_requests")

class Admin(Base):
    __tablename__ = "admins"
    
    id = Column(Integer, primary_key=True, index=True)
    username = Column(String, unique=True)
    password_hash = Column(String)
    created_at = Column(DateTime, default=datetime.utcnow)

class Vehicle(Base):
    __tablename__ = "vehicles"
    
    id = Column(Integer, primary_key=True, index=True)
    vehicle_number = Column(String, unique=True)
    sim_number = Column(String)
    imei_number = Column(String)
    iot_device = Column(String)
    battery_percentage = Column(Integer, default=100)
    location = Column(String, default="Unknown")
    status = Column(String, default="Available")  # Available, Running, Idle, Offline
    ignition_status = Column(Boolean, default=False)  # True=ON, False=OFF
    last_updated = Column(DateTime, default=datetime.utcnow)
    assigned_to = Column(Integer, ForeignKey("riders.id"), nullable=True)
    
    assigned_rider = relationship("Rider", foreign_keys=[assigned_to])

class Wallet(Base):
    __tablename__ = "wallets"
    
    id = Column(Integer, primary_key=True, index=True)
    rider_id = Column(Integer, ForeignKey("riders.id"))
    total_hours = Column(Integer, default=80)
    used_hours = Column(Float, default=0.0)
    available_hours = Column(Float, default=80.0)
    
    rider = relationship("Rider", back_populates="wallet")

class RideHistory(Base):
    __tablename__ = "ride_history"
    
    id = Column(Integer, primary_key=True, index=True)
    rider_id = Column(Integer, ForeignKey("riders.id"))
    vehicle_id = Column(Integer, ForeignKey("vehicles.id"))
    start_time = Column(DateTime)
    end_time = Column(DateTime, nullable=True)
    duration_hours = Column(Float, default=0.0)
    status = Column(String, default="active")  # active, completed
    
    rider = relationship("Rider", back_populates="ride_history")
    vehicle = relationship("Vehicle")

class PaymentHistory(Base):
    __tablename__ = "payment_history"
    
    id = Column(Integer, primary_key=True, index=True)
    rider_id = Column(Integer, ForeignKey("riders.id"))
    amount = Column(Float)
    hours_credited = Column(Integer)
    payment_date = Column(DateTime, default=datetime.utcnow)
    
    rider = relationship("Rider", back_populates="payment_history")