from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List
from datetime import timedelta, datetime
from ..database import get_db
from ..models import Admin, Rider, RiderDocument, TopUpRequest, Wallet, Vehicle, RideHistory, PaymentHistory
from ..schemas import AdminLogin, Token, MessageResponse, AdminCreateRider, VehicleCreate, VehicleAssign
from ..auth import get_password_hash, verify_password, create_access_token, ACCESS_TOKEN_EXPIRE_MINUTES

router = APIRouter(prefix="/api/admin", tags=["Admin"])

@router.post("/login", response_model=Token)
async def admin_login(admin_data: AdminLogin, db: Session = Depends(get_db)):
    admin = db.query(Admin).filter(Admin.username == admin_data.username).first()
    
    if not admin or not verify_password(admin_data.password, admin.password_hash):
        raise HTTPException(status_code=401, detail="Invalid admin credentials")
    
    access_token_expires = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = create_access_token(
        data={"sub": admin.username, "role": "admin"}, expires_delta=access_token_expires
    )
    
    return Token(access_token=access_token, token_type="bearer", role="admin")

@router.get("/dashboard")
async def admin_dashboard(db: Session = Depends(get_db)):
    total_vehicles = db.query(Vehicle).count()
    running_vehicles = db.query(Vehicle).filter(Vehicle.status == "Running").count()
    available_vehicles = db.query(Vehicle).filter(Vehicle.status == "Idle").count()
    total_customers = db.query(Rider).count()
    active_rides = db.query(RideHistory).filter(RideHistory.status == "active").count()
    
    # Calculate total hours from all wallets
    total_hours = db.query(Wallet).with_entities(db.func.sum(Wallet.total_hours)).scalar() or 0
    
    return {
        "total_vehicles": total_vehicles,
        "running_vehicles": running_vehicles,
        "available_vehicles": available_vehicles,
        "customers": total_customers,
        "active_rides": active_rides,
        "total_hours": total_hours
    }

@router.get("/customers")
async def get_all_customers(db: Session = Depends(get_db)):
    riders = db.query(Rider).all()
    result = []
    
    for rider in riders:
        wallet = db.query(Wallet).filter(Wallet.rider_id == rider.id).first()
        assigned_vehicle = db.query(Vehicle).filter(Vehicle.assigned_to == rider.id).first()
        result.append({
            "id": rider.id,
            "full_name": rider.full_name,
            "phone_number": rider.phone_number,
            "wallet_hours": f"{wallet.available_hours}h/{wallet.total_hours}h" if wallet else "0h/0h",
            "assigned_vehicle": assigned_vehicle.vehicle_number if assigned_vehicle else None,
            "last_ride": "5/3/2026"  # Sample data
        })
    
    return result

@router.get("/customers/{rider_id}")
async def get_customer_details(rider_id: int, db: Session = Depends(get_db)):
    rider = db.query(Rider).filter(Rider.id == rider_id).first()
    
    if not rider:
        raise HTTPException(status_code=404, detail="Customer not found")
    
    wallet = db.query(Wallet).filter(Wallet.rider_id == rider_id).first()
    documents = db.query(RiderDocument).filter(RiderDocument.rider_id == rider_id).first()
    ride_history = db.query(RideHistory).filter(RideHistory.rider_id == rider_id).all()
    payment_history = db.query(PaymentHistory).filter(PaymentHistory.rider_id == rider_id).all()
    
    # Format ride history
    rides = []
    for ride in ride_history:
        vehicle = db.query(Vehicle).filter(Vehicle.id == ride.vehicle_id).first()
        rides.append({
            "vehicle": vehicle.vehicle_number if vehicle else "Unknown",
            "start": ride.start_time,
            "end": ride.end_time,
            "duration": f"{ride.duration_hours}h",
            "status": ride.status
        })
    
    # Format payment history
    payments = []
    for payment in payment_history:
        payments.append({
            "date": payment.payment_date.strftime("%Y-%m-%d"),
            "amount": f"₹{payment.amount:,.0f}",
            "hours_credited": f"{payment.hours_credited}h"
        })
    
    return {
        "id": rider.id,
        "full_name": rider.full_name,
        "phone_number": rider.phone_number,
        "aadhaar_number": rider.aadhaar_number,
        "joined": rider.created_at.strftime("%Y-%m-%d"),
        "wallet": {
            "total": f"{wallet.total_hours}h" if wallet else "0h",
            "used": f"{wallet.used_hours}h" if wallet else "0h",
            "remaining": f"{wallet.available_hours}h" if wallet else "0h",
            "usage_percentage": int((wallet.used_hours / wallet.total_hours * 100)) if wallet and wallet.total_hours > 0 else 0
        },
        "documents": {
            "driving_license": {
                "uploaded": bool(documents.driving_license) if documents else False,
                "approved": documents.driving_license_approved if documents else False
            },
            "aadhaar_card": {
                "uploaded": bool(documents.aadhaar_card) if documents else False,
                "approved": documents.aadhaar_card_approved if documents else False
            },
            "pan_card": {
                "uploaded": bool(documents.pan_card) if documents else False,
                "approved": documents.pan_card_approved if documents else False
            },
            "address_proof": {
                "uploaded": bool(documents.address_proof) if documents else False,
                "approved": documents.address_proof_approved if documents else False
            },
            "photo_selfie": {
                "uploaded": bool(documents.photo_selfie) if documents else False,
                "approved": documents.photo_selfie_approved if documents else False
            },
            "overall_status": "Approved" if documents and all([
                documents.driving_license_approved,
                documents.aadhaar_card_approved,
                documents.pan_card_approved,
                documents.address_proof_approved,
                documents.photo_selfie_approved
            ]) else "Pending"
        },
        "ride_history": rides,
        "payment_history": payments
    }

@router.post("/customers/add")
async def add_customer(customer_data: AdminCreateRider, db: Session = Depends(get_db)):
    # Check if phone number already exists
    existing = db.query(Rider).filter(Rider.phone_number == customer_data.phone_number).first()
    if existing:
        raise HTTPException(status_code=400, detail="Phone number already exists")
    
    # Generate temporary password
    temp_password = f"temp{customer_data.phone_number[-4:]}"
    
    # Create rider
    rider = Rider(
        full_name=customer_data.full_name,
        phone_number=customer_data.phone_number,
        aadhaar_number=customer_data.aadhaar_number,
        password_hash=get_password_hash(temp_password),
        is_approved=True  # Admin created customers are auto-approved
    )
    db.add(rider)
    db.commit()
    db.refresh(rider)
    
    # Create wallet
    wallet = Wallet(
        rider_id=rider.id,
        total_hours=customer_data.initial_wallet_hours,
        available_hours=customer_data.initial_wallet_hours
    )
    db.add(wallet)
    
    # Create empty documents record
    documents = RiderDocument(rider_id=rider.id)
    db.add(documents)
    
    db.commit()
    
    return {
        "message": "Customer added successfully",
        "rider_id": rider.id,
        "temporary_password": temp_password
    }

@router.post("/customers/{rider_id}/add-hours")
async def add_customer_hours(rider_id: int, hours: int, db: Session = Depends(get_db)):
    wallet = db.query(Wallet).filter(Wallet.rider_id == rider_id).first()
    
    if not wallet:
        raise HTTPException(status_code=404, detail="Wallet not found")
    
    wallet.total_hours += hours
    wallet.available_hours += hours
    db.commit()
    
    # Add to payment history
    payment = PaymentHistory(
        rider_id=rider_id,
        amount=hours * 50,  # Assuming 50 rupees per hour
        hours_credited=hours
    )
    db.add(payment)
    db.commit()
    
    return MessageResponse(message=f"Added {hours} hours to customer's wallet")

@router.get("/vehicles")
async def get_all_vehicles(db: Session = Depends(get_db)):
    vehicles = db.query(Vehicle).all()
    result = []
    
    for vehicle in vehicles:
        assigned_rider = db.query(Rider).filter(Rider.id == vehicle.assigned_to).first()
        result.append({
            "id": vehicle.id,
            "vehicle_number": vehicle.vehicle_number,
            "sim_number": vehicle.sim_number,
            "imei_number": vehicle.imei_number,
            "iot_device": vehicle.iot_device,
            "battery_percentage": vehicle.battery_percentage,
            "location": vehicle.location,
            "status": vehicle.status,
            "ignition_status": vehicle.ignition_status,
            "last_updated": vehicle.last_updated,
            "assigned_to": assigned_rider.full_name if assigned_rider else "None"
        })
    
    return result

@router.post("/vehicles")
async def add_vehicle(vehicle_data: VehicleCreate, db: Session = Depends(get_db)):
    # Check if vehicle already exists
    existing = db.query(Vehicle).filter(Vehicle.vehicle_number == vehicle_data.vehicle_number).first()
    if existing:
        raise HTTPException(status_code=400, detail="Vehicle already exists")
    
    vehicle = Vehicle(
        vehicle_number=vehicle_data.vehicle_number,
        sim_number=vehicle_data.sim_number,
        imei_number=vehicle_data.imei_number,
        iot_device=vehicle_data.iot_device
    )
    db.add(vehicle)
    db.commit()
    
    return MessageResponse(message="Vehicle added successfully")

@router.get("/vehicles/{vehicle_id}")
async def get_vehicle_details(vehicle_id: int, db: Session = Depends(get_db)):
    vehicle = db.query(Vehicle).filter(Vehicle.id == vehicle_id).first()
    
    if not vehicle:
        raise HTTPException(status_code=404, detail="Vehicle not found")
    
    assigned_rider = db.query(Rider).filter(Rider.id == vehicle.assigned_to).first()
    
    return {
        "id": vehicle.id,
        "vehicle_number": vehicle.vehicle_number,
        "sim_number": vehicle.sim_number,
        "imei_number": vehicle.imei_number,
        "iot_device": vehicle.iot_device,
        "battery_percentage": vehicle.battery_percentage,
        "location": vehicle.location,
        "status": vehicle.status,
        "ignition_status": vehicle.ignition_status,
        "last_updated": vehicle.last_updated,
        "assigned_to": assigned_rider.full_name if assigned_rider else "None"
    }

@router.post("/vehicles/{vehicle_id}/ignition-on")
async def turn_vehicle_on(vehicle_id: int, db: Session = Depends(get_db)):
    vehicle = db.query(Vehicle).filter(Vehicle.id == vehicle_id).first()
    
    if not vehicle:
        raise HTTPException(status_code=404, detail="Vehicle not found")
    
    vehicle.ignition_status = True
    vehicle.status = "Running"
    vehicle.last_updated = datetime.utcnow()
    db.commit()
    
    return MessageResponse(message="Vehicle ignition turned ON")

@router.post("/vehicles/{vehicle_id}/ignition-off")
async def turn_vehicle_off(vehicle_id: int, db: Session = Depends(get_db)):
    vehicle = db.query(Vehicle).filter(Vehicle.id == vehicle_id).first()
    
    if not vehicle:
        raise HTTPException(status_code=404, detail="Vehicle not found")
    
    vehicle.ignition_status = False
    vehicle.status = "Idle"
    vehicle.last_updated = datetime.utcnow()
    db.commit()
    
    return MessageResponse(message="Vehicle ignition turned OFF")

@router.post("/vehicles/assign")
async def assign_vehicle(assignment: VehicleAssign, db: Session = Depends(get_db)):
    vehicle = db.query(Vehicle).filter(Vehicle.id == assignment.vehicle_id).first()
    rider = db.query(Rider).filter(Rider.id == assignment.rider_id).first()
    
    if not vehicle:
        raise HTTPException(status_code=404, detail="Vehicle not found")
    if not rider:
        raise HTTPException(status_code=404, detail="Rider not found")
    
    # Unassign previous vehicle from rider
    if rider.assigned_vehicle_id:
        old_vehicle = db.query(Vehicle).filter(Vehicle.id == rider.assigned_vehicle_id).first()
        if old_vehicle:
            old_vehicle.assigned_to = None
    
    # Assign new vehicle
    vehicle.assigned_to = assignment.rider_id
    rider.assigned_vehicle_id = assignment.vehicle_id
    
    db.commit()
    
    return MessageResponse(message="Vehicle assigned successfully")