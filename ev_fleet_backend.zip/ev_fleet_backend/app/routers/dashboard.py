from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from ..database import get_db
from ..models import Rider, Vehicle, Wallet
from ..schemas import DashboardResponse, VehicleInfo
from ..auth import get_current_user

router = APIRouter(prefix="/api/rider", tags=["Rider Dashboard"])

@router.get("/dashboard")
async def get_dashboard(current_user: dict = Depends(get_current_user), db: Session = Depends(get_db)):
    rider = db.query(Rider).filter(Rider.phone_number == current_user["sub"]).first()
    
    if not rider:
        raise HTTPException(status_code=404, detail="Rider not found")
    
    wallet = db.query(Wallet).filter(Wallet.rider_id == rider.id).first()
    vehicle = db.query(Vehicle).first()
    
    if not vehicle:
        vehicle = Vehicle(
            vehicle_number="EV-1001",
            battery_percentage=78,
            location="MG Road, Bangalore",
            status="Available"
        )
        db.add(vehicle)
        db.commit()
        db.refresh(vehicle)
    
    vehicle_info = VehicleInfo(
        vehicle_id=vehicle.vehicle_number,
        status=vehicle.status,
        battery=vehicle.battery_percentage,
        location=vehicle.location
    )
    
    return DashboardResponse(
        ride_status="Ride in Progress",
        started_at="10:30 AM",
        wallet_hours=wallet.available_hours if wallet else 66,
        vehicle=vehicle_info
    )

@router.get("/profile")
async def get_profile(current_user: dict = Depends(get_current_user), db: Session = Depends(get_db)):
    rider = db.query(Rider).filter(Rider.phone_number == current_user["sub"]).first()
    
    if not rider:
        raise HTTPException(status_code=404, detail="Rider not found")
    
    return {
        "id": rider.id,
        "full_name": rider.full_name,
        "phone_number": rider.phone_number,
        "is_approved": rider.is_approved,
        "created_at": rider.created_at
    }