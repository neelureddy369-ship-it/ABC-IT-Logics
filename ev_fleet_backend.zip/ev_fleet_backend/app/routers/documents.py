from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form
from sqlalchemy.orm import Session
from typing import Optional
import os
import shutil
from ..database import get_db
from ..models import Rider, RiderDocument
from ..schemas import DocumentsResponse, MessageResponse
from ..auth import get_current_user

router = APIRouter(prefix="/api/rider", tags=["Rider Documents"])

UPLOAD_DIR = "uploads"
os.makedirs(UPLOAD_DIR, exist_ok=True)

def save_file(file: UploadFile, rider_id: int, doc_type: str) -> Optional[str]:
    if not file or not file.filename:
        return None
    
    filename = f"{rider_id}_{doc_type}_{file.filename}"
    file_path = os.path.join(UPLOAD_DIR, filename)
    
    with open(file_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)
    
    return file_path

@router.get("/documents")
async def get_documents(current_user: dict = Depends(get_current_user), db: Session = Depends(get_db)):
    rider = db.query(Rider).filter(Rider.phone_number == current_user["sub"]).first()
    
    if not rider:
        raise HTTPException(status_code=404, detail="Rider not found")
    
    documents = db.query(RiderDocument).filter(RiderDocument.rider_id == rider.id).first()
    
    if not documents:
        return DocumentsResponse()
    
    return DocumentsResponse(
        driving_license=documents.driving_license,
        driving_license_approved=documents.driving_license_approved,
        aadhaar_card=documents.aadhaar_card,
        aadhaar_card_approved=documents.aadhaar_card_approved,
        pan_card=documents.pan_card,
        pan_card_approved=documents.pan_card_approved,
        address_proof=documents.address_proof,
        address_proof_approved=documents.address_proof_approved,
        photo_selfie=documents.photo_selfie,
        photo_selfie_approved=documents.photo_selfie_approved
    )

@router.post("/documents/upload")
async def upload_documents(
    driving_license: Optional[UploadFile] = File(None),
    aadhaar_card: Optional[UploadFile] = File(None),
    pan_card: Optional[UploadFile] = File(None),
    address_proof: Optional[UploadFile] = File(None),
    photo_selfie: Optional[UploadFile] = File(None),
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    rider = db.query(Rider).filter(Rider.phone_number == current_user["sub"]).first()
    
    if not rider:
        raise HTTPException(status_code=404, detail="Rider not found")
    
    documents = db.query(RiderDocument).filter(RiderDocument.rider_id == rider.id).first()
    
    if not documents:
        documents = RiderDocument(rider_id=rider.id)
        db.add(documents)
    
    if driving_license:
        documents.driving_license = save_file(driving_license, rider.id, "driving_license")
        documents.driving_license_approved = False
    
    if aadhaar_card:
        documents.aadhaar_card = save_file(aadhaar_card, rider.id, "aadhaar_card")
        documents.aadhaar_card_approved = False
    
    if pan_card:
        documents.pan_card = save_file(pan_card, rider.id, "pan_card")
        documents.pan_card_approved = False
    
    if address_proof:
        documents.address_proof = save_file(address_proof, rider.id, "address_proof")
        documents.address_proof_approved = False
    
    if photo_selfie:
        documents.photo_selfie = save_file(photo_selfie, rider.id, "photo_selfie")
        documents.photo_selfie_approved = False
    
    db.commit()
    
    return MessageResponse(message="Documents uploaded successfully")