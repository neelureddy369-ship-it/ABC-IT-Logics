from fastapi import APIRouter, Depends, HTTPException, status, UploadFile, File, Form
from sqlalchemy.orm import Session
from typing import Optional
import os
import shutil
from datetime import timedelta
from ..database import get_db
from ..models import Rider, RiderDocument, Wallet
from ..schemas import RiderRegister, RiderLogin, Token, RiderResponse, RiderEditProfile, MessageResponse
from ..auth import get_password_hash, verify_password, create_access_token, ACCESS_TOKEN_EXPIRE_MINUTES, get_current_rider

router = APIRouter(prefix="/api/rider", tags=["Rider Authentication"])

UPLOAD_DIR = "uploads"
os.makedirs(UPLOAD_DIR, exist_ok=True)

def save_file(file: UploadFile, rider_id: int, doc_type: str) -> Optional[str]:
    if not file or not file.filename:
        return None
    
    filename = f"{rider_id}_{doc_type}_{file.filename}"
    file_path = os.path.join(UPLOAD_DIR, filename)
    
    with open(file_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)
    
    return file_path

@router.post("/register", response_model=RiderResponse)
async def register_rider(
    full_name: Optional[str] = Form(None),
    phone_number: Optional[str] = Form(None),
    password: Optional[str] = Form(None),
    confirm_password: Optional[str] = Form(None),
    driving_license: Optional[UploadFile] = File(None),
    aadhaar_card: Optional[UploadFile] = File(None),
    pan_card: Optional[UploadFile] = File(None),
    address_proof: Optional[UploadFile] = File(None),
    photo_selfie: Optional[UploadFile] = File(None),
    db: Session = Depends(get_db)
):
    # Check if phone number already exists
    if phone_number and db.query(Rider).filter(Rider.phone_number == phone_number).first():
        raise HTTPException(status_code=400, detail="Phone number already registered")
    
    # Create rider
    hashed_password = get_password_hash(password) if password else None
    rider = Rider(
        full_name=full_name,
        phone_number=phone_number,
        password_hash=hashed_password
    )
    db.add(rider)
    db.commit()
    db.refresh(rider)
    
    # Save documents
    documents = RiderDocument(
        rider_id=rider.id,
        driving_license=save_file(driving_license, rider.id, "driving_license") if driving_license else None,
        aadhaar_card=save_file(aadhaar_card, rider.id, "aadhaar_card") if aadhaar_card else None,
        pan_card=save_file(pan_card, rider.id, "pan_card") if pan_card else None,
        address_proof=save_file(address_proof, rider.id, "address_proof") if address_proof else None,
        photo_selfie=save_file(photo_selfie, rider.id, "photo_selfie") if photo_selfie else None
    )
    db.add(documents)
    
    # Create wallet
    wallet = Wallet(rider_id=rider.id)
    db.add(wallet)
    
    db.commit()
    
    return RiderResponse(message="Registration submitted for admin approval", rider_id=rider.id)

@router.post("/login", response_model=Token)
async def login_rider(rider_data: RiderLogin, db: Session = Depends(get_db)):
    rider = db.query(Rider).filter(Rider.phone_number == rider_data.phone_number).first()
    
    if not rider or not verify_password(rider_data.password, rider.password_hash):
        raise HTTPException(status_code=401, detail="Invalid credentials")
    
    if not rider.is_approved:
        raise HTTPException(status_code=403, detail="Account pending admin approval")
    
    access_token_expires = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = create_access_token(
        data={"sub": rider.phone_number, "role": "rider"}, expires_delta=access_token_expires
    )
    
    return Token(access_token=access_token, token_type="bearer", role="rider")

@router.patch("/profile", response_model=MessageResponse)
async def edit_profile(
    profile_data: RiderEditProfile,
    current_rider: Rider = Depends(get_current_rider),
    db: Session = Depends(get_db)
):
    # Update full name if provided
    if profile_data.full_name:
        current_rider.full_name = profile_data.full_name
    
    # Update password if provided
    if profile_data.current_password and profile_data.new_password:
        if not verify_password(profile_data.current_password, current_rider.password_hash):
            raise HTTPException(status_code=400, detail="Current password is incorrect")
        current_rider.password_hash = get_password_hash(profile_data.new_password)
    
    db.commit()
    return MessageResponse(message="Profile updated successfully")

@router.get("/profile")
async def get_profile(
    current_rider: Rider = Depends(get_current_rider)
):
    return {
        "id": current_rider.id,
        "full_name": current_rider.full_name,
        "phone_number": current_rider.phone_number,
        "is_approved": current_rider.is_approved,
        "created_at": current_rider.created_at
    }

@router.get("/topup-contact")
async def get_topup_contact():
    return {
        "message": "Contact admin for wallet top-up",
        "admin_contact": "+91-9876543210",
        "email": "admin@evfleet.com",
        "note": "Please contact admin to add hours to your wallet"
    }

@router.post("/request-topup")
async def request_topup(
    hours: int,
    current_rider: Rider = Depends(get_current_rider),
    db: Session = Depends(get_db)
):
    return {
        "message": "Contact admin for wallet top-up",
        "admin_contact": "+91-9876543210",
        "email": "admin@evfleet.com",
        "requested_hours": hours,
        "note": f"Please contact admin to add {hours} hours to your wallet"
    }