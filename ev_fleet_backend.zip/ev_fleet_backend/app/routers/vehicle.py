from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from ..database import get_db
from ..models import Rider, Vehicle
from ..schemas import MessageResponse
from ..auth import get_current_rider

router = APIRouter(prefix="/api/rider", tags=["Vehicle Control"])

@router.get("/vehicle")
async def get_vehicle_info(current_rider: Rider = Depends(get_current_rider), db: Session = Depends(get_db)):
    # Get assigned vehicle
    vehicle = None
    if current_rider.assigned_vehicle_id:
        vehicle = db.query(Vehicle).filter(Vehicle.id == current_rider.assigned_vehicle_id).first()
    
    if not vehicle:
        return {
            "message": "No vehicle assigned",
            "vehicle_id": None,
            "status": "No Vehicle",
            "battery": 0,
            "location": "Unknown",
            "can_control": False
        }
    
    return {
        "vehicle_id": vehicle.vehicle_number,
        "status": vehicle.status,
        "battery": vehicle.battery_percentage,
        "location": vehicle.location,
        "ignition_status": vehicle.ignition_status,
        "can_control": True
    }

@router.post("/vehicle/on")
async def turn_vehicle_on(current_rider: Rider = Depends(get_current_rider), db: Session = Depends(get_db)):
    # Get assigned vehicle
    vehicle = None
    if current_rider.assigned_vehicle_id:
        vehicle = db.query(Vehicle).filter(Vehicle.id == current_rider.assigned_vehicle_id).first()
    
    if not vehicle:
        raise HTTPException(status_code=404, detail="No vehicle assigned")
    
    # Check if admin has disabled the vehicle
    if not vehicle.ignition_status:
        return {
            "message": "Waiting for admin to activate vehicle",
            "status": "waiting_for_admin",
            "can_start": False
        }
    
    vehicle.status = "Running"
    db.commit()
    
    return MessageResponse(message="Vehicle started successfully")

@router.post("/vehicle/off")
async def turn_vehicle_off(current_rider: Rider = Depends(get_current_rider), db: Session = Depends(get_db)):
    # Get assigned vehicle
    vehicle = None
    if current_rider.assigned_vehicle_id:
        vehicle = db.query(Vehicle).filter(Vehicle.id == current_rider.assigned_vehicle_id).first()
    
    if not vehicle:
        raise HTTPException(status_code=404, detail="No vehicle assigned")
    
    vehicle.status = "Idle"
    db.commit()
    
    return MessageResponse(message="Vehicle stopped successfully")

@router.get("/vehicle/status")
async def get_vehicle_status(current_rider: Rider = Depends(get_current_rider), db: Session = Depends(get_db)):
    # Get assigned vehicle
    vehicle = None
    if current_rider.assigned_vehicle_id:
        vehicle = db.query(Vehicle).filter(Vehicle.id == current_rider.assigned_vehicle_id).first()
    
    if not vehicle:
        return {
            "status": "No Vehicle", 
            "battery": 0, 
            "location": "Unknown",
            "message": "No vehicle assigned"
        }
    
    # Check if admin has disabled ignition
    if not vehicle.ignition_status:
        return {
            "status": "Waiting for admin",
            "battery": vehicle.battery_percentage,
            "location": vehicle.location,
            "message": "Waiting for admin to activate vehicle",
            "can_start": False
        }
    
    return {
        "status": vehicle.status,
        "battery": vehicle.battery_percentage,
        "location": vehicle.location,
        "can_start": True
    }