from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from ..database import get_db
from ..models import Rider, Wallet
from ..schemas import WalletResponse
from ..auth import get_current_user

router = APIRouter(prefix="/api/rider", tags=["Rider Wallet"])

@router.get("/wallet")
async def get_wallet(current_user: dict = Depends(get_current_user), db: Session = Depends(get_db)):
    rider = db.query(Rider).filter(Rider.phone_number == current_user["sub"]).first()
    
    if not rider:
        raise HTTPException(status_code=404, detail="Rider not found")
    
    wallet = db.query(Wallet).filter(Wallet.rider_id == rider.id).first()
    
    if not wallet:
        wallet = Wallet(rider_id=rider.id)
        db.add(wallet)
        db.commit()
        db.refresh(wallet)
    
    return WalletResponse(
        available_hours=wallet.available_hours,
        used_hours=wallet.used_hours,
        total_hours=wallet.total_hours
    )

@router.post("/wallet/add-hours")
async def add_hours(hours: int, current_user: dict = Depends(get_current_user), db: Session = Depends(get_db)):
    rider = db.query(Rider).filter(Rider.phone_number == current_user["sub"]).first()
    
    if not rider:
        raise HTTPException(status_code=404, detail="Rider not found")
    
    wallet = db.query(Wallet).filter(Wallet.rider_id == rider.id).first()
    
    if wallet:
        wallet.total_hours += hours
        wallet.available_hours += hours
        db.commit()
    
    return {"message": f"Added {hours} hours to wallet"}