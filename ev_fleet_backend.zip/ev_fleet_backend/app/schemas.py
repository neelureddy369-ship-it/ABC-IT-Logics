from pydantic import BaseModel
from typing import Optional
from datetime import datetime

class RiderRegister(BaseModel):
    full_name: Optional[str] = None
    phone_number: Optional[str] = None
    password: Optional[str] = None
    confirm_password: Optional[str] = None

class RiderLogin(BaseModel):
    phone_number: str
    password: str

class RiderEditProfile(BaseModel):
    full_name: Optional[str] = None
    current_password: Optional[str] = None
    new_password: Optional[str] = None

class TopUpRequest(BaseModel):
    hours: int
    rider_id: int
    status: str = "pending"

class AdminLogin(BaseModel):
    username: str
    password: str

class AdminCreateRider(BaseModel):
    full_name: str
    phone_number: str
    aadhaar_number: str
    initial_wallet_hours: int = 0

class VehicleCreate(BaseModel):
    vehicle_number: str
    sim_number: str
    imei_number: str
    iot_device: str

class VehicleAssign(BaseModel):
    rider_id: int
    vehicle_id: int

class Token(BaseModel):
    access_token: str
    token_type: str
    role: str

class RiderResponse(BaseModel):
    message: str
    rider_id: Optional[int] = None

class VehicleInfo(BaseModel):
    vehicle_id: str
    status: str
    battery: int
    location: str

class DashboardResponse(BaseModel):
    ride_status: str
    started_at: str
    wallet_hours: int
    vehicle: VehicleInfo

class WalletResponse(BaseModel):
    available_hours: int
    used_hours: int
    total_hours: int

class DocumentsResponse(BaseModel):
    driving_license: Optional[str] = None
    driving_license_approved: Optional[bool] = False
    aadhaar_card: Optional[str] = None
    aadhaar_card_approved: Optional[bool] = False
    pan_card: Optional[str] = None
    pan_card_approved: Optional[bool] = False
    address_proof: Optional[str] = None
    address_proof_approved: Optional[bool] = False
    photo_selfie: Optional[str] = None
    photo_selfie_approved: Optional[bool] = False

class MessageResponse(BaseModel):
    message: str

class ApprovalRequest(BaseModel):
    rider_id: int
    document_type: str
    approved: bool