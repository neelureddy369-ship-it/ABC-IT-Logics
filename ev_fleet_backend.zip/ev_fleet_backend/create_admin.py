from app.database import SessionLocal, engine
from app.models import Admin, Base
from app.auth import get_password_hash

# Create tables
Base.metadata.create_all(bind=engine)

# Create admin user
db = SessionLocal()

# Check if admin already exists
existing_admin = db.query(Admin).filter(Admin.username == "admin").first()

if not existing_admin:
    admin = Admin(
        username="admin",
        password_hash=get_password_hash("admin123")
    )
    db.add(admin)
    db.commit()
    print("Admin user created successfully!")
    print("Username: admin")
    print("Password: admin123")
else:
    print("Admin user already exists!")
    print("Username: admin")
    print("Password: admin123")

db.close()