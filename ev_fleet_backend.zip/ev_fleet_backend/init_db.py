from app.database import engine, Base
from app.models import Admin
from app.auth import get_password_hash
from sqlalchemy.orm import sessionmaker

def init_database():
    try:
        # Create all tables
        Base.metadata.create_all(bind=engine)
        print("Database tables created successfully")
        
        # Create session
        SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
        db = SessionLocal()
        
        # Check if admin already exists
        existing_admin = db.query(Admin).filter(Admin.username == 'admin').first()
        
        if not existing_admin:
            # Create default admin
            admin = Admin(
                username='admin',
                password_hash=get_password_hash('admin123')
            )
            db.add(admin)
            db.commit()
            print("Default admin created: username=admin, password=admin123")
        else:
            print("Admin already exists")
        
        db.close()
        print("Database initialization completed")
        
    except Exception as e:
        print(f"Database initialization failed: {e}")
        print("Make sure PostgreSQL is running and database 'ABC IT DB' exists")

if __name__ == "__main__":
    init_database()