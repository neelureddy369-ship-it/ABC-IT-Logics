from app.database import SessionLocal, engine
from app.models import Base
from sqlalchemy import text

# Create database connection
db = SessionLocal()

try:
    # Add missing columns to riders table
    db.execute(text("ALTER TABLE riders ADD COLUMN IF NOT EXISTS aadhaar_number VARCHAR"))
    db.execute(text("ALTER TABLE riders ADD COLUMN IF NOT EXISTS assigned_vehicle_id INTEGER"))
    
    # Add missing columns to vehicles table
    db.execute(text("ALTER TABLE vehicles ADD COLUMN IF NOT EXISTS sim_number VARCHAR"))
    db.execute(text("ALTER TABLE vehicles ADD COLUMN IF NOT EXISTS imei_number VARCHAR"))
    db.execute(text("ALTER TABLE vehicles ADD COLUMN IF NOT EXISTS iot_device VARCHAR"))
    db.execute(text("ALTER TABLE vehicles ADD COLUMN IF NOT EXISTS ignition_status BOOLEAN DEFAULT FALSE"))
    db.execute(text("ALTER TABLE vehicles ADD COLUMN IF NOT EXISTS last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP"))
    db.execute(text("ALTER TABLE vehicles ADD COLUMN IF NOT EXISTS assigned_to INTEGER"))
    
    # Change wallet columns to FLOAT
    db.execute(text("ALTER TABLE wallets ALTER COLUMN used_hours TYPE FLOAT USING used_hours::FLOAT"))
    db.execute(text("ALTER TABLE wallets ALTER COLUMN available_hours TYPE FLOAT USING available_hours::FLOAT"))
    
    # Create new tables if they don't exist
    db.execute(text("""
        CREATE TABLE IF NOT EXISTS ride_history (
            id SERIAL PRIMARY KEY,
            rider_id INTEGER REFERENCES riders(id),
            vehicle_id INTEGER REFERENCES vehicles(id),
            start_time TIMESTAMP,
            end_time TIMESTAMP,
            duration_hours FLOAT DEFAULT 0.0,
            status VARCHAR DEFAULT 'active'
        )
    """))
    
    db.execute(text("""
        CREATE TABLE IF NOT EXISTS payment_history (
            id SERIAL PRIMARY KEY,
            rider_id INTEGER REFERENCES riders(id),
            amount FLOAT,
            hours_credited INTEGER,
            payment_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """))
    
    db.commit()
    print("Database migration completed successfully!")
    
except Exception as e:
    print(f"Migration error: {e}")
    db.rollback()
    
finally:
    db.close()